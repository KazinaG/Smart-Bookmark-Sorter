async function initialize() {
    // console.log('initialize実行開始');
    await getTree();
    node = await setViewsToAllNode(node);
    // console.log('initialize実行終了');
};

function getTree() {
    return new Promise((resolve, reject) => {
        chrome.bookmarks.getTree((rootList) => {
            node = getBookmarks(rootList);
            resolve();
        });
    });
}

function getBookmarks(rootList) {
    // ルートオブジェクトの取得
    let root_defaultBookmark = rootList[0];
    // ルートオブジェクトから最上位のデフォルトのブックマークフォルダの配列の取得
    let defaultBookmarkList = root_defaultBookmark['children'];
    // 「ブックマークバー」の取得 0:ブックマークバー 1:その他ブックマーク 2:モバイルブックマーク
    let bookmarkBarNode = defaultBookmarkList[0];
    return bookmarkBarNode;
};

async function setViewsToAllNode(tmpNode) {
    if (tmpNode.children) {
        tmpNode = await setVisitCount(tmpNode);
        let childrenNode = tmpNode.children;
        for (let i in childrenNode) { childrenNode[i] = await setViewsToAllNode(childrenNode[i]); };
        tmpNode.children = childrenNode;
    } else if (tmpNode.url) { tmpNode = await setVisitCount(tmpNode); };
    return tmpNode;
};